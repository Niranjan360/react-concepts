
const Fragments = () => 
{
    return (
            <>
                <h1>This is custom component</h1>
                <p>lorem ipsum</p>
            </>
    );
}
 
export default Fragments;

/*
Fragments
    In react components , if we need to return multiple 
    JSX we have to enclose it in one outer container.

    To preveent the multiple duplicate divisions , we can 
    use JSX fragments <> </>
 */
