const Child = ({a,b,c}) => {

    return ( <>
                <h1>{a}</h1>
                <h1>{b}</h1>
                <h1>{c}</h1>
            </> );
}
 
export default Child;