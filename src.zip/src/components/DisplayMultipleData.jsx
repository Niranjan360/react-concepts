import { useState , useEffect } from "react";

const DisplayMultipleData = () => {

    let [recipes , setRecipes] = useState(null);

    useEffect( ()=>{
        setTimeout(()=>{
            fetch("https://dummyjson.com/recipes")
            .then((res)=>{return res.json()})
            .then((data)=>{
                console.log(data.recipes);
                setRecipes(data.recipes);
        })
        } , 3000)
    } , [] )

    return(
            <div>

            {recipes==null && <div id="loader"></div>}

            {recipes!=null && <div className="card-list">
                                {
                                    recipes.map((v,i,a)=>{return(<div key={v.id} className="card">
                                                                    <img src={v.image} width="230px" height="200px" />
                                                                    <h1>{v.name} </h1>
                                                                    <h2>{v.rating}</h2>
                                                                </div>)})
                                }
                                </div>}
            </div>
    )
}
export default DisplayMultipleData;




















// import { useState , useEffect } from "react";

// const DisplayMultipleData = () => {

//     let [users , setUsers] = useState(null);

//     useEffect( ()=>{
//         setTimeout(()=>{
//             fetch("https://dummyjson.com/users")
//             .then((res)=>{return res.json()})
//             .then((data)=>{
//                 console.log(data.users.slice(0,10));
//                 setUsers(data.users.slice(0,10));// 1) update the state   2) re-render the comp
//         })
//         } , 3000)
//     } , [] )

//     return(
//             <div>

//             {users==null && <h1>Please wait ! data is loading</h1>}

//             {users!=null && <div className="card-list">
//                                 {
//                                     users.map((v,i,a)=>{return(<div key={v.id} className="card">
//                                                                     <h1>{v.username} </h1>
//                                                                     <h2>Age : {v.age}</h2>
//                                                                     <h3>Phone : {v.phone}</h3>
//                                                                 </div>)})
//                                 }
//                                 </div>}
//             </div>
//     )
// }
// export default DisplayMultipleData;













// import { useState } from "react";

// const DisplayMultipleData = () => {
//     let [users , setUsers] = useState(
//         [
//             {uname:"king" , id:1 , age:32 , phone:9876543211},
//             {uname:"adam" , id:2 , age:23 , phone:9876543212},
//             {uname:"alex" , id:3 , age:56 , phone:9876543213},
//             {uname:"stark" , id:4 , age:21 , phone:9876543214},
//             {uname:"tony" , id:5, age:20 , phone:9876543215},
//             {uname:"scot" , id:6 , age:45 , phone:9876543216},
//         ]);

//     return(
//             <div className="card-list">
//             {
//                 users.map((v,i,a)=>{return(<div key={v.id} className="card">
//                                                 <h1>Username : {v.uname} </h1>
//                                                 <h2>Age : {v.age}</h2>
//                                                 <h3>Phone : {v.phone}</h3>
//                                             </div>)})
//             }
//             </div>
//     )
// }
// export default DisplayMultipleData;


