
const EventHandling = () => 
{
    let x = ()=>{
        console.log("Non parameterised function");
    }
    let y = (num)=>{
        console.log(num + " Parameterised function");
    }
    return ( <div>
                <h1>Event handling in React</h1>
                <hr />
                {/* if a function is with zero parameter , then pass only function's reference */}
                <button onClick={x}> invoke x </button>

                {/* if a fuction is with paremeter , use call function and invoke the same */}
                <button onClick={()=>{ y(10) }}> invoke y </button>
            </div> );
}
export default EventHandling;
/**
 Event handling  

    In React event handling can be done in two ways

    -> use callbacks if the function is parameterised
    -> pass the function ref if the function is non-parameterised
 */