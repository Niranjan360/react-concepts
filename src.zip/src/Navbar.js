function Navbar()
{
    return(
        <nav>
            <h1>Logo</h1>
            <button>Logout</button>
        </nav>
    )
}

export default Navbar;