import { memo, useContext } from "react";
import Greatgrandchild from "./Greatgrandchild";
import { UserContext } from "./Parent";

const Grandchild = () => {

    console.log("grand child comp rendered");

    return ( <div>
                <h1>This is a Grand child component</h1>
                <hr />
                <Greatgrandchild/>
            </div> );
}
 
export default memo(Grandchild); 