import { memo, useContext } from "react";
import { UserContext } from "./Parent";

const Greatgrandchild = () => {

    console.log(" great grand child comp rendered");

    let count = useContext(UserContext);
    
    return( <div>
            <h1>This is a Great Grand child component</h1>
            <h2> count  {count} </h2>
        </div> )
}
 
export default memo(Greatgrandchild); 