import { memo } from "react";

const Child = ({val1 , updateValue1 , obj}) => {

    console.log("child comp rendered");

    return ( <div>
                <h1>This is a child component</h1>
                <h2 onClick={updateValue1}> VAL 1  {val1} </h2>

            </div> );
}
 
export default memo(Child); // memorized child 

// // if and only if previous prop and current prop are different then only component will be rerendered
// // previous prop != current prop  ==> re-renders the componnet






/*---------------------------------context api ------------------------------------- */
// import { memo } from "react";
// import Grandchild from "./Grandchild";

// const Child = () => {

//     console.log("child comp rendered");

//     return ( <div>
//                 <h1>This is a child component</h1>
//                 <hr />
//                 <Grandchild/>
//             </div> );
// }
 
// export default memo(Child); 