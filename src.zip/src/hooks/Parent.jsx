import { useCallback, useState } from "react";
import Child from "./Child";

import { useReducer } from "react";

const Parent = () => {

    console.log("parent comp rendered");

    let[val1 , setVAl1] = useState(10);
    let[val2 , setVAl2] = useState(100);

    // recreate callback if and only if val1 is changed
    let updateValue1 = useCallback(()=>{setVAl1(val1+10)} , [val1])

    // recreate callback if and only if val2 is changed
    let updateValue2 = useCallback(()=>{setVAl2(val2+100)} , [val2])

    let obj = useCallback({x:val1} , [val1]) // np

    return ( <div>
                <h1>This is a parent component</h1>
                <h2> VAL 1  {val1} </h2>
                <h2> VAL 2  {val2} </h2>

                <button onClick={updateValue1}> update val 1</button>
                <button onClick={updateValue2}> update val 2</button>

                <hr />
                <Child val1={val1} updateValue1={updateValue1} obj={obj}/>
            </div> );
}
 
export default Parent;



/*--------------------------------------- context api----------------------------------------- */

// import { createContext, useState } from "react";
// import Child from "./Child";
// export let UserContext = createContext()

// const Parent = () => {

//     console.log("parent comp rendered");

//     let[count , setCount] = useState(10);

//     return ( <div>
//                 <h1>This is a parent component</h1>
//                 <h2 onClick={()=>{setCount(count+10)}}> count  {count} </h2>
//                 <hr />

//                 <UserContext.Provider value={count}>
//                     <Child/>
//                 </UserContext.Provider>
                
//             </div> );
// }
 
// export default Parent;


/*----------------------------------- before useReducer------------------------------------------------- */


// import { createContext, useState } from "react";
// import Child from "./Child";
// export let UserContext = createContext()

// const Parent = () => {

//     let[c1 , setC1] = useState(1);
//     let[c2 , setC2] = useState(10);
//     let[c3 , setC3] = useState(100);

//     let incrementC1 = ()=>{
//         setC1(c1+1)
//     }
//     let incrementC2 = ()=>{
//         setC2(c2+10)
//     }
//     let incrementC3 = ()=>{
//         setC3(c3+100)
//     }
//     let decrementC1 = ()=>{
//         setC1(c1-1)
//     }
//     let decrementC2 = ()=>{
//         setC2(c2-10)
//     }
//     let decrementC3 = ()=>{
//         setC3(c3-100)
//     }

//     return ( <div>
//                     <h1>C1 : {c1} </h1>
//                     <button onClick={incrementC1}>+</button>
//                     <button onClick={decrementC1}>-</button>

//                     <hr />

//                     <h1>C2 : {c2} </h1>
//                     <button onClick={incrementC2}>+</button>
//                     <button onClick={decrementC2}>-</button>

//                     <hr />

//                     <h1>C3 : {c3} </h1>
//                     <button onClick={incrementC3}>+</button>
//                     <button onClick={decrementC3}>-</button>
//             </div> );
// }
 
// export default Parent;

/*----------------------------------after reducer--------------------------------------- */

// let initstate = {c1:1 , c2:10 , c3:100 };

// let reducer = (prvState , action)=>{
//     switch(action.type)
//     {
//         case "incrementC1" : return {...prvState , c1: prvState.c1+1 } ;
//         case "decrementC1" : return {...prvState , c1: prvState.c1-1 } ;
//         case "incrementC2" : return {...prvState , c2: prvState.c2+10 } ;
//         case "decrementC2" : return {...prvState , c2: prvState.c2-10 } ;
//         case "incrementC3" : return {...prvState , c3: prvState.c3+100 } ;
//         case "decrementC3" : return {...prvState , c3: prvState.c3-100 } ;
//     }
// }

// const Parent = () => {
//     let[state , dispatch] = useReducer(reducer , initstate);    
//     return ( <div>
//                     <h1>C1 : {state.c1} </h1>
//                     <button onClick={()=>{dispatch({type:"incrementC1"})}}>+</button>
//                     <button onClick={()=>{dispatch({type:"decrementC1"})}}>-</button>
//                     <hr />
//                     <h1>C2 : {state.c2} </h1>
//                     <button onClick={()=>{dispatch({type:"incrementC2"})}}>+</button>
//                     <button onClick={()=>{dispatch({type:"decrementC2"})}}>-</button>
//                     <hr />
//                     <h1>C3 : {state.c3} </h1>
//                     <button onClick={()=>{dispatch({type:"incrementC3"})}}>+</button>
//                     <button onClick={()=>{dispatch({type:"decrementC3"})}}>-</button>
//             </div> );
// }

// export default Parent;