function Home()
{
    return(
        <div>
            <h1>this is homee component</h1>
            <p>qwertyuiopoihgfdxcvbjhfdfgh</p>
        </div>
    )
}

export default Home;