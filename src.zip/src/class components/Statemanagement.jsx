import { Component, PureComponent } from "react";

class Statemanagement extends PureComponent
{
    constructor()
    {
        super()
        this.state = {count1: 10 , count2 :100}
    }
    render()
    {
        console.log("comp rendered");

        return(
            <div>
                <h1>This is a class component</h1>
                <h1>count1 : {this.state.count1} </h1>
                <button onClick={()=>{ this.setState({count1 : this.state.count1 +0})  }}> 
                    inc count1 
                </button>
            </div>
        )
    }
}
export default Statemanagement;










// import { useState } from "react";

// const Statemanagement = () => {

//     let[count1 , setCount1] = useState(10);  

//     console.log("comp rendered");

//     return ( <div>
//                 <h1>Count1: {count1}</h1>
//                 <button onClick={()=>{setCount1(count1+0)}}> update count1 </button>
//             </div>  );
// }
 
// export default Statemanagement;
