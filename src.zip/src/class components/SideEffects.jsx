import { Component } from "react";

class SideEffects extends Component
{
    componentDidMount()
    {
        console.log("component Did Mount");
        this.state = {count:10}
    }
    render()
    {
        console.log("render");
        return(
            <div>
                <h1>This is class comp</h1>
                <h2>count : {this.state.count}</h2>
                <button onClick={()=>{this.setState({count:this.state.count+10})}}>
                    update state and re-render comp
                </button>
            </div>
        )
    }
    constructor()
    {
        console.log("contructor");
        super();
        this.state = {count : 10};
    }
    
    
    componentDidUpdate()
    {
        console.log("component Did Update");
    }
    componentWillUnmount()
    {
        console.log("component Will Unmount");
    } 
}
export default SideEffects