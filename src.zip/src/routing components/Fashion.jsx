const Fashion = () => {

    return ( <div className="fs">
                <h1>Fashion comp</h1>
            </div> );
}
 
export default Fashion;