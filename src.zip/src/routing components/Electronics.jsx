const Electronics = () => {

    return ( <div className="elec">
                <h1>Electronics comp</h1>
            </div> );
}
 
export default Electronics;