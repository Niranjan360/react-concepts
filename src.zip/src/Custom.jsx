
function Custom()
{
    //state or dynamic values 
    let a = 10; // number

    return(
        <div>
            <h1>this is custom component</h1>

            <h2> a value is :  {a} </h2>
        </div>
    )
}

export default Custom;


















// import {Component} from 'react'

// class Custom extends Component
// {
//     // inbuilt method of Componeent class
//     constructor()
//     {
//         super();
//     }
//     render()
//     {
//         return (
//                     <div>
//                         <h1> this is class component</h1>
//                     </div>
//         )    
//     }
// }

// export default Custom;