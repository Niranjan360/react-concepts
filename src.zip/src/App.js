import { useState } from 'react';
import './App.css';
import Sample from './class components/Statemanagement';
import ConditionalRendering from './components/ConditionalRendering';
import DisplayMultipleData from './components/DisplayMultipleData';
import EventHandling from './components/EventHandling';
import Fragments from './components/Fragments';
import Mode from './components/Mode';
import Parent from './hooks/Parent';
import SideEffect from './components/SideEffects';
import Electronics from './routing components/Electronics';
import Fashion from './routing components/Fashion';
import Home from './routing components/Home';
import Navbar from './routing components/Navbar';
import {BrowserRouter , Routes , Route} from 'react-router-dom'
import Statemanagement from './class components/Statemanagement';
import SideEffects from './class components/SideEffects';




function App() 
{
    return (
            <div className="App">
                <Parent/>
            </div>
    )   
}   

export default App;


